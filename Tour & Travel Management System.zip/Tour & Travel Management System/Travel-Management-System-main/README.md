# Travel-Management-System
Tour and Travel Managemnt System using JAVA , JAVA-Swing &amp; MySQL

This is my first fully functionalble project using any Data-Base as MySQL

1. All images icons are in icons folder
2. ALL source code are in src/travel/management/system folder
3. used MySQL as DATA_BASE


1->  open login file  
add details in username and password textfield
  
<img width="440" alt="image" src="https://user-images.githubusercontent.com/101044019/192492113-e3d3c993-9fbc-4b29-929f-3e4ae35a49f9.png">

 
   1.1-> if youu are new then go to sighnup.
   
   <img width="352" alt="image" src="https://user-images.githubusercontent.com/101044019/192492757-59ee6f2c-010a-4ec9-9950-5c4a48b22268.png">

   
   1.2->  if you forget the password then go to ForgerPassword.
   memtion username and question answred  you will find out your password from there
   
   <img width="439" alt="image" src="https://user-images.githubusercontent.com/101044019/192492847-a1c80965-9623-47c1-9aef-47bde8cc3117.png">

2-> if you entered correct username and password you will find welcome note.

<img width="314" alt="image" src="https://user-images.githubusercontent.com/101044019/192493523-686aa3cd-0400-4e09-9713-bdc9b45c1240.png">

3-> Main Dashbord or heart of my project.

<img width="683" alt="image" src="https://user-images.githubusercontent.com/101044019/192493700-ed3a1b76-508c-4d5d-b622-85fb24fe9cd1.png">
3.1 -> Logout will dend back to login page;

3.2->  Add personal Details will help you in adding details.

<img width="414" alt="image" src="https://user-images.githubusercontent.com/101044019/192494168-f45d01da-a3c5-4201-b348-642e60db6557.png">

3.3-> Update detalis;

<img width="410" alt="image" src="https://user-images.githubusercontent.com/101044019/192494392-f19877f5-7b22-43bc-bd15-4d888cacd518.png">

3.4-> View Persional Details:

<img width="410" alt="image" src="https://user-images.githubusercontent.com/101044019/192494490-ddb2f70c-94f5-48cb-aef7-3c3b7eb5611c.png">

3.5->Delete details will delete all your details from DataBase:


3.6-> check package and book package;

<img width="725" alt="image" src="https://user-images.githubusercontent.com/101044019/192494821-29b953a1-09a9-4200-843a-66e6e167e687.png">

 3.7-> view booked package;
 
<img width="412" alt="image" src="https://user-images.githubusercontent.com/101044019/192494934-bc7c7597-5d47-4daf-9033-1d72326b3058.png">

3.8 -> View Hotels And book Hotels:

<img width="726" alt="image" src="https://user-images.githubusercontent.com/101044019/192495180-fb5bbd26-9a43-41fa-a92a-a7b599b86e13.png">

3.9->  View Booked Hotels:

<img width="626" alt="image" src="https://user-images.githubusercontent.com/101044019/192495320-317bb96a-bf1e-469f-a537-b380ebb987c6.png">

3.10->  Payment
will land you in paytm but dont pay unless you like my work:

<img width="620" alt="image" src="https://user-images.githubusercontent.com/101044019/192495645-28635795-670d-4fd6-9368-c7edaf69162b.png">

3.11 -> Destination;
the places wil add soon on this


3.12 -> About  will display all the details of the project and use of it.


 4 --> Conn .java   file will connnect all data from MySQL to this ;
 
 <img width="430" alt="image" src="https://user-images.githubusercontent.com/101044019/192496394-7e7c27bb-8a65-47e9-8b5f-ba7a5016d916.png">
